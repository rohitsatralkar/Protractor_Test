export class commonFunctions {

  public navigateTo(text:string) {
    return browser.get(text);
  }

  public enterSearchInput(text: string, sendKeysLocator: element) { 
    return sendKeysLocator.sendKeys(text);
  }
  
  public clickBtn(clickBtnLocator: element) { 
    return clickBtnLocator.click();
  }

  public matchSearchResultItems(resultLocator: element) {
	 return resultLocator.getText();
  }
  
  public getItemCount(resultLocator: element) {
	 return resultLocator.count();
  }
  
  public clearField(fieldLocator: element)
  {
	  return fieldLocator.clear();
  }
  
  public pressEnterKey(enterKeyLocator: element)
  {
	  return enterKeyLocator.sendKeys(protractor.Key.ENTER);
  }
   
}