let nameInput=element(by.xpath("//input[@type='search' and @id='query']"));
let searchBtn=element(by.xpath("//button[@type='submit']"));
let characterText=element(by.xpath("//app-character//h6"));
let characterDetails=element.all(by.xpath("//app-character//div[@class='row']/div[2]"));
let notFoundText=element(by.xpath("//app-search-form/../div[1]"));

import { commonFunctions } from '../commfuncs/commFunc.ts';

export class CharacterObjs {
  public commonFunc:commonFunctions = new commonFunctions();

  public navigateTo(text:string) {
    return this.commonFunc.navigateTo(text);
  }

  public enterSearchInput(text: string) { 
    return this.commonFunc.enterSearchInput(text, nameInput);
  }
  
  public clickBtn() { 
    return this.commonFunc.clickBtn(searchBtn);
  }

  public verifySearchResultItems(text: string) {
	  if(text=="valid")
	  {
		  return this.commonFunc.matchSearchResultItems(characterDetails);
	  }
	  else
	  {
		  return this.commonFunc.matchSearchResultItems(notFoundText);
	  }
  }
 
}