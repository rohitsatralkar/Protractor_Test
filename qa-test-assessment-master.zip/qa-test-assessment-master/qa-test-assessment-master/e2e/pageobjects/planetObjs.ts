let nameInput=element(by.xpath("//input[@type='search' and @id='query']"));
let searchBtn=element(by.xpath("//button[@type='submit']"));
let planetBtn=element(by.xpath("//input[@id='planets']"));
let planetText=element(by.xpath("//app-planets//h6"));
let planetDetails=element.all(by.xpath("//app-planet//div[@class='row']/div[2]"));
let notFoundText=element(by.xpath("//app-search-form/../div[1]"));

import { commonFunctions } from '../commfuncs/commFunc.ts';

export class PlanetObjs {
  public commonFunc:commonFunctions = new commonFunctions();

  public navigateTo(text:string) {
    return this.commonFunc.navigateTo(text);
  }

  public enterSearchInput(text: string) { 
    return this.commonFunc.enterSearchInput(text, nameInput);
  }
  
  public clickBtn() { 
    return this.commonFunc.clickBtn(searchBtn);
  }
  
  public clickPlanetBtn() { 
    return this.commonFunc.clickBtn(planetBtn);
  }

  public verifySearchResultItems(text: string) {
	  if(text=="valid")
	  {
		  return this.commonFunc.matchSearchResultItems(planetDetails);
	  }
	  else
	  {
		  return this.commonFunc.matchSearchResultItems(notFoundText);
	  }
  }
 
}