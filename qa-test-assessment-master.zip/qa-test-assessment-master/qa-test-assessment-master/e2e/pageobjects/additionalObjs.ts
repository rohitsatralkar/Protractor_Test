let characterCount=element.all(by.xpath("//app-character//div[@class='card-body']"));
let planetCount=element.all(by.xpath("//app-planet//div[@class='card-body']"));
let nameInput=element(by.xpath("//input[@type='search' and @id='query']"));
let searchBtn=element(by.xpath("//button[@type='submit']"));
let peopleBtn=element(by.xpath("//input[@id='people']"));

import { commonFunctions } from '../commfuncs/commFunc.ts';

export class AdditionalObjs {
  public commonFunc:commonFunctions = new commonFunctions();

  public getElementCount(text: string) {
	if(text=="character")
	{
		return this.commonFunc.getItemCount(characterCount);
	}
	else if(text=="planet"){
		return this.commonFunc.getItemCount(planetCount);
	}
  }
  
  public clearInputField()
  {
	  return this.commonFunc.clearField(nameInput);
  }
  
  public clickSearchBtn()
  {
	  return this.commonFunc.clickBtn(searchBtn);
  }
  
  public enterInput(text: string)
  {
	  return this.commonFunc.enterSearchInput(text,nameInput);
  }
  
  public pressEnter()
  {
	  return this.commonFunc.pressEnterKey(searchBtn);
  }
  
  public clickPeopleRadioBtn()
  {
	  return this.commonFunc.clickBtn(peopleBtn);
  }
}