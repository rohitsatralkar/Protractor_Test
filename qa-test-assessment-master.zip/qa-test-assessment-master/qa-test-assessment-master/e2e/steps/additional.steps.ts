const chai = require('chai');
chai.use(require('chai-as-promised'));

import { AdditionalObjs } from '../pageobjects/additionalObjs.ts';
let additionalObj = AdditionalObjs;
     
	 Before(function(){
    additionalObj=new AdditionalObjs();
	})

	 When('if there are multiple results in {string}', async (string)=> {
		let count= await additionalObj.getElementCount(string);
		await chai.expect(count).to.be.above(1);
         });
		 
	 When('when I clear the search form and click search button', async ()=> {
		await additionalObj.clearInputField();
        await additionalObj.clickSearchBtn();
         });
		 
	  
	 Then('I get an empty search result for {string}', async (string)=>{
        let count= await additionalObj.getElementCount(string);
		await chai.expect(count).to.equal(0);
           
         });
		 
	 When('I search for a {string} by pressing the enter key', async (string)=> {
		await additionalObj.clearInputField();
		await additionalObj.enterInput(string);
		await additionalObj.pressEnter();
         });
		 
	 When('I switch to people', async ()=> {
		await additionalObj.clickPeopleRadioBtn();
         });	

	 When('I click on searchBtn with the previous search still filled', async ()=> {
		await additionalObj.clickSearchBtn();
         });