const chai = require('chai');
chai.use(require('chai-as-promised'));

import { CharacterObjs } from '../pageobjects/characterObj.ts';
let characterObj = CharacterObjs;
     
	 Before(function(){
    characterObj=new CharacterObjs();
	})
	 
	 Given('The app is open on {string}', { timeout: 25 * 1000 }, async (string) => {
		  await characterObj.navigateTo('http://' + string + ':4200/');
         });

	 When('I search for a {string}', async (string)=> {
		await characterObj.enterSearchInput(string);
		await characterObj.clickBtn();
         });

      Then('I am able to see {string}, {string}, {string} and {string} for a search that is {string}.', async (gender, birthYear, eyeColor, skinColor, isValid)=> {
		 let characterValsFromUI= await characterObj.verifySearchResultItems(isValid);
		 await chai.expect(characterValsFromUI).to.have.all.members([gender, birthYear, eyeColor, skinColor]);
         });
		 
	  
	  Then('I am able to see {string} for a search that is {string}.', async(notFoundString, isNotValid) =>{
		 let characterValsFromUI= await characterObj.verifySearchResultItems(isNotValid);
		 await chai.expect(characterValsFromUI).to.equal(notFoundString);
	  });