const chai = require('chai');
chai.use(require('chai-as-promised'));

import { PlanetObjs } from '../pageobjects/planetObjs.ts';
let planetObj = PlanetObjs;
     
	 Before(function(){
    planetObj=new PlanetObjs();
	})

	 When('I search for a planet {string}', async (string)=> {
		await planetObj.clickPlanetBtn(); 
		await planetObj.enterSearchInput(string);
		await planetObj.clickBtn();
         });

      Then('I am able to see {string}, {string}, {string} for a search that is {string}.', async (population, climate,gravity, isValid)=> {
		 let planetValsFromUI= await planetObj.verifySearchResultItems(isValid);
		 await chai.expect(planetValsFromUI).to.have.all.members([population, climate,gravity]);
         });
		 